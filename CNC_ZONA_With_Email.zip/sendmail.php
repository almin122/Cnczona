<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ime = strip_tags(trim($_POST["ime"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $poruka = trim($_POST["poruka"]);

    $to = "cnczona@outlook.com";
    $subject = "Nova poruka sa CNC ZONA sajta";
    $body = "Ime: $ime
Email: $email

Poruka:
$poruka";
    $headers = "From: $ime <$email>";

    if (mail($to, $subject, $body, $headers)) {
        echo "Poruka uspešno poslata!";
    } else {
        echo "Greška pri slanju. Pokušajte kasnije.";
    }
}
?>
